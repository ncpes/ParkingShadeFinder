# ParkingShadeFinder easy upload

This archive contains the complete Android Studio project.

For GitHub mobile upload, upload this ZIP as a single file first.
Then create `.github/workflows/build.yml` in the repository and use the
workflow supplied separately by ChatGPT. The workflow will extract this
archive and build the APK automatically.
