# 愛車遮陽停車 ParkingShadeFinder v0.1

第一版 Android 原型：以「地下／室內／立體／遮棚」為核心的停車場搜尋器。

## 不用 Android Studio 也能編譯

1. 建立一個 GitHub repository。
2. 將這個專案資料夾內的所有檔案上傳到 repository 的 `main` 分支。
3. 開啟 GitHub 的 **Actions**。
4. 選擇 **Build Android APK**。
5. 按 **Run workflow**（或直接 push 到 main 自動編譯）。
6. 工作完成後，進入該次 workflow，在 **Artifacts** 下載 `ParkingShadeFinder-debug-apk`。
7. 解壓縮後即可取得 `app-debug.apk`，安裝到 Android 手機／平板。

## 資料核實原則

- 第一版只把官方／公部門資料可確認的停車場放入資料庫。
- 「立體」不自動等於「室內」；遮蔽程度另行確認。
- 無法確認的停車場不列入愛車推薦。
- 下一階段再加入 Google 地點相片／評論的交叉驗證。
