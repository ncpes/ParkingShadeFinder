package com.example.parkingshadefinder;

import android.Manifest;import android.app.*;import android.os.*;import android.content.*;import android.content.pm.PackageManager;import android.location.*;import android.net.Uri;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
 static class P {String n,a,t,e; double lat,lon; P(String n,String a,String t,String e,double lat,double lon){this.n=n;this.a=a;this.t=t;this.e=e;this.lat=lat;this.lon=lon;}}
 ArrayList<P> data=new ArrayList<>(); ArrayList<P> shown=new ArrayList<>(); ListView list; TextView status; Location loc;
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main); list=findViewById(R.id.list);status=findViewById(R.id.status);
   seed(); findViewById(R.id.allBtn).setOnClickListener(v->show("all"));findViewById(R.id.indoorBtn).setOnClickListener(v->show("indoor"));findViewById(R.id.shelterBtn).setOnClickListener(v->show("shelter"));
   list.setOnItemClickListener((p,v,pos,id)->nav(shown.get(pos))); locate(); show("all"); }
 void seed(){
   // High-confidence examples verified against Kaohsiung official/public sources during prototype build.
   data.add(new P("岡山立體停車場","高雄市岡山區大仁北路3號","立體","官方資料確認：立體停車場；未判定為完整室內/地下",22.7966,120.3015));
   data.add(new P("文化中心地下停車場","高雄市苓雅區五福一路67號","地下","官方資料確認：地下 B1",22.6267,120.3137));
   data.add(new P("四維立體停車場","高雄市苓雅區苓雅一路226號","立體","官方資料確認：立體；遮蔽程度仍待照片核實",22.6238,120.3120));
   data.add(new P("美術館立體停車場","高雄市鼓山區馬卡道路324號","立體","官方資料確認：立體；遮蔽程度仍待照片核實",22.6577,120.2869));
   data.add(new P("凱旋醫院旁地下停車場","高雄市苓雅區凱旋二路130號","地下","官方資料確認：地下 B1",22.6187,120.3256));
 }
 void locate(){if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},10);return;} LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);try{loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);if(loc==null)loc=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);if(loc!=null)status.setText(String.format(Locale.TAIWAN,"目前位置：%.4f, %.4f",loc.getLatitude(),loc.getLongitude()));}catch(Exception e){status.setText("無法取得位置，仍可瀏覽核實資料");}}
 void show(String f){shown.clear();for(P p:data){if(f.equals("indoor") && !p.t.equals("地下"))continue;if(f.equals("shelter"))continue;shown.add(p);} Collections.sort(shown,(x,y)->Double.compare(dist(x),dist(y)));ArrayList<String> rows=new ArrayList<>();for(P p:shown){String d=loc==null?"距離未知":String.format(Locale.TAIWAN,"約 %.1f km",dist(p));rows.add("★ "+p.n+"\n"+p.t+"｜"+d+"\n"+p.a+"\n"+p.e);}list.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,rows));}
 double dist(P p){if(loc==null)return 99999;float[] r=new float[1];Location.distanceBetween(loc.getLatitude(),loc.getLongitude(),p.lat,p.lon,r);return r[0]/1000.0;}
 void nav(P p){Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q="+Uri.encode(p.a)));try{startActivity(i);}catch(Exception e){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/maps/search/?api=1&query="+Uri.encode(p.a))));}}
 @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==10&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)locate();else status.setText("未允許定位；仍可瀏覽核實資料");}
}
