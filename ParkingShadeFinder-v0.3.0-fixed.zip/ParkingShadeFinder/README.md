# ParkingShadeFinder v0.3.0

愛車防曬型停車搜尋器（高雄）

## 本版
- 內建 28 筆核實愛車停車場
- 地下／室內立體／遮棚優先分類
- 防曬 1～5 星
- GPS 可用時依距離排序；沒有可靠 GPS 時保留地址導航，不猜座標
- 點擊停車場可開啟 Google Maps 導航
- 使用者可新增遺漏停車場，資料保存在手機 SQLite
- APK 升級時保留使用者新增資料

## GitHub Actions
推送到 main 或手動執行 workflow 即可使用 Gradle 8.9 + Java 17 建置 Debug APK。
