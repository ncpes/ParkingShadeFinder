package com.example.parkingshadefinder;

import android.Manifest;
import android.app.*;
import android.os.Bundle;
import android.os.Build;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.location.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static class P {
        long id; String name,address,type,note,source; int score; double lat,lon;
        P(long id,String name,String address,String type,int score,String note,String source,double lat,double lon){
            this.id=id;this.name=name;this.address=address;this.type=type;this.score=score;this.note=note;this.source=source;this.lat=lat;this.lon=lon;
        }
    }

    static class DB extends SQLiteOpenHelper {
        static final String NAME="parking_shade.db"; static final int VER=3;
        DB(Context c){super(c,NAME,null,VER);}
        public void onCreate(SQLiteDatabase db){
            db.execSQL("CREATE TABLE parking(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,address TEXT,type TEXT NOT NULL,score INTEGER,note TEXT,source TEXT,lat REAL,lon REAL,created_at INTEGER)");
            seed(db);
        }
        public void onUpgrade(SQLiteDatabase db,int oldV,int newV){
            if(oldV<3){
                // 更新內建資料，但保留使用者自行新增的資料。
                db.delete("parking","source=?",new String[]{"內建愛車資料"});
                db.delete("parking","source=?",new String[]{"內建核實資料"});
                seed(db);
            }
        }
        void seed(SQLiteDatabase db){
            // 2026-10 核實版：以高雄市政府交通局、營運商官方資料及地圖資料交叉核實。
            add(db,"民權停車場（民權國小地下停車場）","高雄市前鎮區泰山街1號","地下",5,"B1地下停車場；完全遮蔽優先推薦。","高雄市交通局＋地圖核實",22.608298,120.315859);
            add(db,"文化中心地下停車場","高雄市苓雅區五福一路67號","地下",5,"地下停車場；完全遮蔽。","高雄市交通局＋地圖核實",22.627123,120.318888);
            add(db,"財稅大樓地下停車場","高雄市新興區中正三路25號","地下",5,"地下停車場；完全遮蔽。","高雄市交通局＋地圖核實",22.630674,120.309858);
            add(db,"正好停－自強地下停車場","高雄市前金區文武一街65號","地下",5,"地下立體停車場；完全遮蔽。","高雄市交通局＋地圖核實",22.631162,120.293440);
            add(db,"五甲國宅社區地下停車場","高雄市鳳山區國隆路6號","地下",5,"地下1～2層；完全遮蔽。","高雄市交通局＋地圖核實",22.616454,120.347375);
            add(db,"高雄醫大地下停車場","高雄市三民區同盟一路82號","地下",5,"高雄醫學大學地下停車場；完全遮蔽。","地圖＋校方資料核實",0,0);
            add(db,"歐特儀－鳳山車站地下停車場","高雄市鳳山區曹公路133巷13號","地下",5,"鳳山車站地下停車場；完全遮蔽。","地圖＋營運資料核實",0,0);
            add(db,"鳳山運動園區地下停車場","高雄市鳳山區立志街與體育路附近","地下",5,"地下立體停車場；完全遮蔽。","高雄市交通局＋地圖核實",22.623137,120.354463);
            add(db,"高雄國際會議中心附設停車場","高雄市鹽埕區中正四路274號B1～B3","地下",5,"地下1～3層；完全遮蔽。","高雄市交通局＋場館資料",22.6266595,120.2855480);
            add(db,"高雄港旅運中心地下停車場","高雄市苓雅區海邊路5號B1～B2","地下",5,"地下1～2層；完全遮蔽。","高雄市交通局＋地圖核實",0,0);
            add(db,"衛武營國家藝術文化中心地下停車場","高雄市鳳山區三多一路1號B1～B2","地下",5,"官方資料明確為B1、B2地下停車場。","衛武營官方＋高雄市交通局",22.62430782,120.34095690);
            add(db,"大東文化藝術中心地下停車場","高雄市鳳山區光遠路161號B1","地下",5,"B1地下停車場；完全遮蔽。","大東官方＋地圖核實",22.6249879,120.36258067);
            add(db,"高雄巨蛋計時停車場","高雄市左營區博愛二路767、777號B2～B3","地下",5,"地下二、三層；完全遮蔽。","高雄市交通局＋地圖資料",22.667980,120.300700);
            add(db,"霖園國泰中央廣場停車場","高雄市前鎮區中山二路260號B4～B5","地下",5,"地下4～5層；完全遮蔽。","高雄市交通局＋停車資料",0,0);
            add(db,"光武國小地下停車場","高雄市三民區光武路35號","地下",5,"地下停車場；完全遮蔽。","高雄市交通局＋地圖核實",22.639506,120.334803);
            add(db,"水利會停車場","高雄市左營區明誠二路332號B2～B3","地下",5,"B2、B3地下停車場；完全遮蔽。","高雄市交通局＋停車資料",22.661298,120.308237);
            add(db,"H2O 水京棧停車場","高雄市鼓山區明華路366號B2～B4","地下",5,"飯店官方確認B2～B4皆為停車場；室內遮蔽。","H2O官方資料",22.662789,120.302100);
            add(db,"城市車旅國泰中正站停車場","高雄市新興區中正三路2號B1～B3","地下",5,"地下第一～三層；完全遮蔽。","CITY PARKING官方＋停車資料",0,0);
            add(db,"中正和平站停車場（大統百貨）","高雄市苓雅區和平一路218號","地下／建物立體",5,"地下停車入口；以室內地下樓層優先。名稱以目前地圖資料為準。","地圖＋使用者提供街景證據",0,0);
            add(db,"高雄高工公有立體停車場","高雄市三民區大順二路338號","地上立體",4,"地上多層立體；有樓層遮蔽，但非地下。","高雄市交通局＋地圖核實",22.647358,120.323102);
            add(db,"十全立體停車場","高雄市三民區十全路6號","地上立體",4,"地上立體；樓層車位具遮蔽。","高雄市交通局＋地圖核實",22.645086,120.314642);
            add(db,"正好停－武廟立體停車場","高雄市苓雅區輔仁路123號","地上立體",4,"地上立體；部分樓層遮蔽，非地下。","高雄市交通局＋地圖核實",22.628847,120.332577);
            add(db,"林園區立體停車場","高雄市林園區林園南路77號","地上立體",4,"地上立體；樓層具遮蔽。","高雄市交通局＋地圖核實",22.502752,120.395874);
            add(db,"民權輕鋼架停車場","高雄市新興區民權一路221號","地上立體／遮棚",4,"地上輕鋼架立體；有遮蔽但非地下。","高雄市交通局＋地圖核實",22.623527,120.311551);
            add(db,"高鐵左營站P1立體停車場","高雄市左營區高鐵路103號P1 2F～4F","室內立體",4,"高鐵站P1立體停車場；室內樓層遮蔽。","一卡通＋地圖資料",0,0);
            add(db,"福山立體停車場（福山國小地下）","高雄市左營區重信路35號","地下／立體",5,"官方資料標示地下立體；完全遮蔽。","高雄市交通局＋一卡通資料",22.683526,120.316536);
            add(db,"凹子底停五立體停車場","高雄市左營區孟子路503號","地下＋地上立體",4,"地下1層＋地上1、3～6層；混合型，地下優先。","高雄市交通局＋民營停車場資料",0,0);
            add(db,"合發前金立體停車場","高雄市前金區前金二街30號","地下＋地上立體",4,"B2至地上多層；混合型，非純地下。","高雄市交通局＋營運資料",0,0);
        }
        void add(SQLiteDatabase db,String n,String a,String t,int s,String note,String source,double lat,double lon){
            android.content.ContentValues v=new android.content.ContentValues();
            v.put("name",n);v.put("address",a);v.put("type",t);v.put("score",s);v.put("note",note);v.put("source",source);v.put("lat",lat);v.put("lon",lon);v.put("created_at",System.currentTimeMillis());db.insert("parking",null,v);
        }
    }

    DB db; ArrayList<P> data=new ArrayList<>(),shown=new ArrayList<>(); ListView list; TextView status; Location loc;
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);db=new DB(this);list=findViewById(R.id.list);status=findViewById(R.id.status);
        findViewById(R.id.allBtn).setOnClickListener(v->show("all"));
        findViewById(R.id.indoorBtn).setOnClickListener(v->show("indoor"));
        findViewById(R.id.shelterBtn).setOnClickListener(v->show("shelter"));
        findViewById(R.id.addBtn).setOnClickListener(v->addParkingDialog());
        findViewById(R.id.userBtn).setOnClickListener(v->show("user"));
        list.setOnItemClickListener((p,v,pos,id)->nav(shown.get(pos))); locate(); show("all"); }

    void load(){data.clear();Cursor c=db.getReadableDatabase().query("parking",null,null,null,null,null,null);try{while(c.moveToNext())data.add(new P(c.getLong(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("address")),c.getString(c.getColumnIndexOrThrow("type")),c.getInt(c.getColumnIndexOrThrow("score")),c.getString(c.getColumnIndexOrThrow("note")),c.getString(c.getColumnIndexOrThrow("source")),c.getDouble(c.getColumnIndexOrThrow("lat")),c.getDouble(c.getColumnIndexOrThrow("lon"))));}finally{c.close();}}

    void show(String f){load();shown.clear();for(P p:data){boolean indoor=p.type.contains("地下")||p.type.contains("室內");boolean shelter=p.type.contains("遮棚")||p.type.contains("立體");boolean user=p.source.equals("使用者新增");if(f.equals("indoor")&&!indoor)continue;if(f.equals("shelter")&&!shelter)continue;if(f.equals("user")&&!user)continue;shown.add(p);}Collections.sort(shown,(x,y)->Double.compare(dist(x),dist(y)));ArrayList<String> rows=new ArrayList<>();for(P p:shown){String d=p.lat==0?"GPS待補・可用地址導航":(loc==null?"距離未知":String.format(Locale.TAIWAN,"約 %.1f km",dist(p)));String stars="";for(int i=0;i<p.score;i++)stars+="★";String badge=p.source.equals("使用者新增")?"【使用者新增・待核實】":"【已核實愛車資料】";rows.add(stars+" "+p.name+"\n"+p.type+"｜"+d+" "+badge+"\n"+p.address+"\n"+p.note);}list.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,rows));status.setText("內建核實愛車停車場："+countBuiltIn()+" 筆　｜　使用者新增："+countUser()+" 筆");}
    int countBuiltIn(){int n=0;for(P p:data)if(!p.source.equals("使用者新增"))n++;return n;}
    int countUser(){int n=0;for(P p:data)if(p.source.equals("使用者新增"))n++;return n;}
    double dist(P p){if(loc==null||p.lat==0)return 999999;float[] r=new float[1];Location.distanceBetween(loc.getLatitude(),loc.getLongitude(),p.lat,p.lon,r);return r[0]/1000.0;}
    void locate(){if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},10);return;}LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);try{loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);if(loc==null)loc=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);if(loc!=null)status.setText(String.format(Locale.TAIWAN,"目前位置：%.4f, %.4f",loc.getLatitude(),loc.getLongitude()));}catch(Exception e){}}

    void addParkingDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,8,24,0);
        EditText name=new EditText(this);name.setHint("停車場名稱（必填）");box.addView(name);
        EditText addr=new EditText(this);addr.setHint("地址或位置（必填）");box.addView(addr);
        Spinner type=new Spinner(this);String[] types={"地下","室內立體","遮棚立體","遮棚平面","半遮棚","其他"};type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,types));box.addView(type);
        Spinner score=new Spinner(this);String[] scores={"★★★★★ 5分","★★★★ 4分","★★★ 3分","★★ 2分","★ 1分"};score.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,scores));box.addView(score);
        EditText note=new EditText(this);note.setHint("補充資訊：限高、車位、遮蔽情況、收費等（選填）");note.setMinLines(3);box.addView(note);
        new AlertDialog.Builder(this).setTitle("＋新增愛車停車場").setMessage("把資料庫沒有的室內、立體或遮棚停車場補進來。新增後會標示為『使用者新增・待核實』。")
            .setView(box).setNegativeButton("取消",null).setPositiveButton("新增",(d,w)->{String n=name.getText().toString().trim(),a=addr.getText().toString().trim();if(n.isEmpty()||a.isEmpty()){Toast.makeText(this,"名稱與地址不能空白",Toast.LENGTH_LONG).show();return;}int s=5-score.getSelectedItemPosition();android.content.ContentValues v=new android.content.ContentValues();v.put("name",n);v.put("address",a);v.put("type",type.getSelectedItem().toString());v.put("score",s);v.put("note",note.getText().toString().trim().isEmpty()?"由使用者補充，尚待核實":note.getText().toString().trim());v.put("source","使用者新增");v.put("lat",0);v.put("lon",0);v.put("created_at",System.currentTimeMillis());db.getWritableDatabase().insert("parking",null,v);Toast.makeText(this,"已加入愛車停車資料庫",Toast.LENGTH_SHORT).show();show("all");}).show();
    }
    void nav(P p){Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("google.navigation:q="+Uri.encode(p.address)));try{startActivity(i);}catch(Exception e){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/maps/search/?api=1&query="+Uri.encode(p.address))));}}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==10&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)locate();}
}
