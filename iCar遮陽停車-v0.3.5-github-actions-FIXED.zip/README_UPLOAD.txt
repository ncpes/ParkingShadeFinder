iCar遮陽停車 v0.3.5

GitHub upload package.
請先刪除 GitHub repo 裡舊的 ParkingShadeFinder*.zip，再上傳本 ZIP。
本 ZIP 解壓後會以最新版本覆蓋 ParkingShadeFinder 專案，並驗證 versionName=0.3.5、App 名稱=iCar遮陽停車。
